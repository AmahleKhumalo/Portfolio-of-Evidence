// script.js - Vuyamahle Creations Homepage Enhancements

// ===== MAIN INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
    console.log('Vuyamahle Creations website initialized');
    initializeHomepage();
});

function initializeHomepage() {
    // Remove loading screen
    setTimeout(removeLoadingScreen, 1500);
    
    // Initialize all features
    updateCopyrightYear();
    setupImageEnhancements();
    setupVideoEnhancements();
    setupNavigationEffects();
    loadDynamicContent();
    setupScrollAnimations();
    setupVisitorCounter();
    setupTypewriterEffect();
    
    console.log('All homepage features initialized successfully');
}

// ===== LOADING SCREEN =====
function removeLoadingScreen() {
    const loadingScreen = document.getElementById('loadingScreen');
    if (loadingScreen) {
        loadingScreen.style.opacity = '0';
        setTimeout(() => {
            loadingScreen.style.display = 'none';
        }, 500);
    }
}

// ===== DYNAMIC CONTENT =====
function loadDynamicContent() {
    loadFeatures();
    loadTestimonials();
}

function loadFeatures() {
    const featuresGrid = document.getElementById('featuresGrid');
    if (!featuresGrid) return;

    const features = [
        {
            icon: '👗',
            title: 'Bespoke Fashion',
            description: 'Custom-designed clothing tailored to your unique style and preferences'
        },
        {
            icon: '🍽️',
            title: 'Gourmet Catering',
            description: 'Exceptional culinary experiences for all your special occasions'
        },
        {
            icon: '⭐',
            title: '15 Years Excellence',
            description: 'Proven track record of delivering premium quality since 2009'
        },
        {
            icon: '💎',
            title: 'Luxury Service',
            description: 'High-class outcomes with attention to every detail'
        }
    ];

    featuresGrid.innerHTML = features.map(feature => `
        <div class="feature-card">
            <div class="feature-icon">${feature.icon}</div>
            <h3>${feature.title}</h3>
            <p>${feature.description}</p>
        </div>
    `).join('');

    // Add animation to feature cards
    const featureCards = document.querySelectorAll('.feature-card');
    featureCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.2}s`;
        card.classList.add('fade-in-up');
    });
}

function loadTestimonials() {
    const testimonialContainer = document.getElementById('testimonialContainer');
    if (!testimonialContainer) return;

    const testimonials = [
        {
            name: 'Sarah M.',
            service: 'Wedding Dress',
            text: 'Vuyamahle created the most beautiful wedding dress I could have imagined! Attention to detail was incredible.',
            rating: 5
        },
        {
            name: 'James T.',
            service: 'Corporate Event Catering',
            text: 'Their catering service made our corporate event unforgettable. The food was exceptional!',
            rating: 5
        },
        {
            name: 'Linda K.',
            service: 'Fashion Design',
            text: '15 years of excellence truly shows in their work. My custom outfit received so many compliments!',
            rating: 5
        }
    ];

    testimonialContainer.innerHTML = testimonials.map(testimonial => `
        <div class="testimonial-card">
            <div class="testimonial-text">"${testimonial.text}"</div>
            <div class="testimonial-author">
                <strong>${testimonial.name}</strong> - ${testimonial.service}
            </div>
            <div class="testimonial-rating">
                ${'⭐'.repeat(testimonial.rating)}
            </div>
        </div>
    `).join('');

    // Auto-rotate testimonials
    startTestimonialRotation();
}

// ===== INTERACTIVE ELEMENTS =====
function setupImageEnhancements() {
    const mainLogo = document.getElementById('mainLogo');
    if (mainLogo) {
        mainLogo.addEventListener('click', function() {
            this.classList.toggle('enlarged');
            if (this.classList.contains('enlarged')) {
                showImageModal(this.src, this.alt);
            }
        });

        // Add parallax effect on scroll
        window.addEventListener('scroll', function() {
            if (mainLogo) {
                const scrolled = window.pageYOffset;
                const rate = scrolled * -0.3;
                mainLogo.style.transform = `translateY(${rate}px) scale(1.02)`;
            }
        });
    }
}

function setupVideoEnhancements() {
    const introVideo = document.getElementById('introVideo');
    if (introVideo) {
        // Add custom video controls
        introVideo.addEventListener('loadedmetadata', function() {
            console.log('Video duration:', this.duration, 'seconds');
        });

        introVideo.addEventListener('play', function() {
            console.log('Video started playing');
            // Track video plays (you can add analytics here)
        });

        // Auto-pause when not in viewport
        setupVideoViewportDetection();
    }
}

function setupVideoViewportDetection() {
    const video = document.getElementById('introVideo');
    if (!video) return;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (!entry.isIntersecting && !video.paused) {
                video.pause();
            }
        });
    }, { threshold: 0.5 });

    observer.observe(video);
}

// ===== ANIMATIONS AND EFFECTS =====
function setupScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);

    // Observe all sections for animation
    document.querySelectorAll('section, .feature-card, .testimonial-card').forEach(el => {
        observer.observe(el);
    });
}

function setupTypewriterEffect() {
    const welcomeBanner = document.querySelector('.welcome-banner h1');
    if (welcomeBanner) {
        const text = welcomeBanner.textContent;
        welcomeBanner.textContent = '';
        welcomeBanner.style.borderRight = '2px solid white';
        
        let i = 0;
        function typeWriter() {
            if (i < text.length) {
                welcomeBanner.textContent += text.charAt(i);
                i++;
                setTimeout(typeWriter, 100);
            } else {
                welcomeBanner.style.borderRight = 'none';
            }
        }
        
    // Start typewriter after loading screen
    setTimeout(typeWriter, 1600);
    }
}

// ===== UTILITY FUNCTIONS =====
function updateCopyrightYear() {
    const yearElement = document.getElementById('currentYear');
    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }
}

function setupNavigationEffects() {
    const navLinks = document.querySelectorAll('nav a');
    
    navLinks.forEach(link => {
        link.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
            this.style.transition = 'all 0.3s ease';
        });
        
        link.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });

        // Add active page highlighting
        if (link.href === window.location.href) {
            link.classList.add('active');
        }
    });
}

function setupVisitorCounter() {
    let count = localStorage.getItem('visitorCount') || 0;
    count = parseInt(count) + 1;
    localStorage.setItem('visitorCount', count);
    
    const counterElement = document.getElementById('visitorCounter');
    if (counterElement) {
        // Animate counter
        let current = parseInt(counterElement.textContent);
        const increment = Math.ceil(count / 50);
        
        const timer = setInterval(() => {
            current += increment;
            if (current >= count) {
                current = count;
                clearInterval(timer);
            }
            counterElement.textContent = current;
        }, 30);
    }
}

// ===== MODAL FUNCTIONALITY =====
function showImageModal(src, alt) {
    const modal = document.createElement('div');
    modal.className = 'image-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close-modal">&times;</span>
            <img src="${src}" alt="${alt}">
            <div class="modal-caption">${alt}</div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Close modal functions
    modal.addEventListener('click', function(e) {
        if (e.target === modal || e.target.classList.contains('close-modal')) {
            document.body.removeChild(modal);
        }
    });
    
    // Close on escape key
    document.addEventListener('keydown', function closeOnEscape(e) {
        if (e.key === 'Escape') {
            document.body.removeChild(modal);
            document.removeEventListener('keydown', closeOnEscape);
        }
    });
}

// ===== TESTIMONIAL ROTATION =====
function startTestimonialRotation() {
    const testimonials = document.querySelectorAll('.testimonial-card');
    if (testimonials.length === 0) return;
    
    let currentIndex = 0;
    
    setInterval(() => {
        testimonials.forEach(testimonial => testimonial.classList.remove('active'));
        currentIndex = (currentIndex + 1) % testimonials.length;
        testimonials[currentIndex].classList.add('active');
    }, 5000);
}

// ===== PERFORMANCE OPTIMIZATIONS =====
// Debounce scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Optimized scroll handler
window.addEventListener('scroll', debounce(function() {
    // Any scroll-based calculations here
}, 10));

// ===== ERROR HANDLING =====
window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
});

// Export for global access if needed
window.VuyamahleApp = {
    initializeHomepage,
    showImageModal,
    updateCopyrightYear
};

console.log('Vuyamahle Creations JavaScript loaded successfully');

const toggleSearch = () => {
    const searchform = document.querySelector('.search-form');
    const searchButton = document.querySelector('.search-button');
    const searchInput = document.querySelector('.search-input');

    searchButton.addEventListener('click', () => {
      searchForm.classList.toggle('active-search');
});

searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        searchInput.value ='';    
        searchForm.classList.remove('active-search');
    }
});
};

toggleSearch();