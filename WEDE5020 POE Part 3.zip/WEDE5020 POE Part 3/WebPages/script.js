// ===== VUYAMAHLE CREATIONS WEBSITE JAVASCRIPT =====
// script.js - Separate JavaScript functionality

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeWebsite();
});

function initializeWebsite() {
    updateCopyrightYear();
    initializeImageLoading();
    initializeNavigation();
    initializeGallery();
    initializeContactForms();
    loadDynamicContent();
    initializeVideoEnhancements();
}

// ===== UTILITY FUNCTIONS =====

// Update copyright year automatically
function updateCopyrightYear() {
    const yearElement = document.getElementById('currentYear');
    if (yearElement) {
        yearElement.textContent = 'Est. 2009 | Current Year: ' + new Date().getFullYear();
    }
}

// Smooth image loading with fade-in effect
function initializeImageLoading() {
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        // Add loading state
        img.style.opacity = '0';
        img.style.transition = 'opacity 0.5s ease';
        
        // Fade in when loaded
        if (img.complete) {
            img.style.opacity = '1';
        } else {
            img.addEventListener('load', function() {
                this.style.opacity = '1';
            });
            
            // Handle loading errors
            img.addEventListener('error', function() {
                console.warn('Image failed to load:', this.src);
                this.style.opacity = '1';
                this.alt = 'Image not available';
            });
        }
    });
}

// ===== NAVIGATION ENHANCEMENTS =====

function initializeNavigation() {
    // Smooth scrolling for same-page navigation
    document.querySelectorAll('nav a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Add active state to current page in navigation
    highlightCurrentPage();
}

function highlightCurrentPage() {
    const currentPage = window.location.pathname.split('/').pop() || 'home.html';
    const navLinks = document.querySelectorAll('nav a');
    
    navLinks.forEach(link => {
        const linkHref = link.getAttribute('href');
        if (linkHref === currentPage) {
            link.style.background = 'rgba(255,255,255,0.3)';
            link.style.fontWeight = 'bold';
        }
    });
}

// ===== GALLERY FUNCTIONALITY =====

function initializeGallery() {
    const galleryImages = document.querySelectorAll('.gallery img');
    
    galleryImages.forEach(img => {
        // Add click functionality for modal
        img.style.cursor = 'pointer';
        img.addEventListener('click', function() {
            openImageModal(this.src, this.alt);
        });
        
        // Add hover description
        img.setAttribute('title', 'Click to enlarge');
    });
}

function openImageModal(imgSrc, imgAlt) {
    // Create modal overlay
    const modal = document.createElement('div');
    modal.className = 'image-modal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.9);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 2000;
        cursor: pointer;
    `;
    
    // Create modal content
    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
        position: relative;
        max-width: 90%;
        max-height: 90%;
        text-align: center;
    `;
    
    const modalImg = document.createElement('img');
    modalImg.src = imgSrc;
    modalImg.alt = imgAlt;
    modalImg.style.cssText = `
        max-width: 100%;
        max-height: 80vh;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.5);
    `;
    
    const modalCaption = document.createElement('p');
    modalCaption.textContent = imgAlt;
    modalCaption.style.cssText = `
        color: white;
        margin-top: 15px;
        font-size: 1.1em;
    `;
    
    // Create close button
    const closeBtn = document.createElement('button');
    closeBtn.innerHTML = '&times;';
    closeBtn.style.cssText = `
        position: absolute;
        top: -40px;
        right: -40px;
        background: #8B4513;
        color: white;
        border: none;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        font-size: 1.5em;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
    `;
    
    // Assemble modal
    modalContent.appendChild(modalImg);
    modalContent.appendChild(modalCaption);
    modalContent.appendChild(closeBtn);
    modal.appendChild(modalContent);
    document.body.appendChild(modal);
    
    // Close modal functions
    function closeModal() {
        document.body.removeChild(modal);
        document.removeEventListener('keydown', handleEscape);
    }
    
    function handleEscape(e) {
        if (e.key === 'Escape') {
            closeModal();
        }
    }
    
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModal();
        }
    });
    
    closeBtn.addEventListener('click', closeModal);
    document.addEventListener('keydown', handleEscape);
}

// ===== CONTACT FORM HANDLING =====

function initializeContactForms() {
    const contactForms = document.querySelectorAll('form');
    
    contactForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            if (validateForm(this)) {
                handleFormSubmission(this);
            }
        });
        
        // Add real-time validation
        const inputs = form.querySelectorAll('input, textarea');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
            
            input.addEventListener('input', function() {
                clearFieldError(this);
            });
        });
    });
}

function validateForm(form) {
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!validateField(field)) {
            isValid = false;
        }
    });
    
    // Validate email format
    const emailField = form.querySelector('input[type="email"]');
    if (emailField && emailField.value) {
        if (!isValidEmail(emailField.value)) {
            showFieldError(emailField, 'Please enter a valid email address');
            isValid = false;
        }
    }
    
    return isValid;
}

function validateField(field) {
    const value = field.value.trim();
    
    if (field.hasAttribute('required') && !value) {
        showFieldError(field, 'This field is required');
        return false;
    }
    
    if (field.type === 'email' && value && !isValidEmail(value)) {
        showFieldError(field, 'Please enter a valid email address');
        return false;
    }
    
    clearFieldError(field);
    return true;
}

function showFieldError(field, message) {
    clearFieldError(field);
    
    field.style.borderColor = '#dc3545';
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    errorDiv.style.cssText = `
        color: #dc3545;
        font-size: 0.9em;
        margin-top: 5px;
    `;
    
    field.parentNode.appendChild(errorDiv);
}

function clearFieldError(field) {
    field.style.borderColor = '';
    
    const existingError = field.parentNode.querySelector('.field-error');
    if (existingError) {
        existingError.remove();
    }
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function handleFormSubmission(form) {
    // Show loading state
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'Sending...';
    submitBtn.disabled = true;
    
    // Simulate form submission (replace with actual API call)
    setTimeout(() => {
        alert('Thank you for your message! We will get back to you soon.');
        form.reset();
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
    }, 2000);
}

// ===== DYNAMIC CONTENT LOADING =====

function loadDynamicContent() {
    loadFeatures();
    initializeCounters();
}

function loadFeatures() {
    const featuresSection = document.getElementById('featuresSection');
    if (!featuresSection) return;
    
    const features = [
        {
            icon: '🎨',
            title: 'Bespoke Fashion Designs',
            description: 'Custom-made clothing that reflects your unique style and personality'
        },
        {
            icon: '🍽️',
            title: 'Exceptional Catering',
            description: 'Gourmet food services for all your special occasions and events'
        },
        {
            icon: '⭐',
            title: '15 Years Excellence',
            description: 'Proven track record of delivering high-quality services since 2009'
        },
        {
            icon: '💎',
            title: 'Luxury Outcomes',
            description: 'Commitment to providing premium, high-class results for every client'
        }
    ];
    
    featuresSection.innerHTML = features.map(feature => `
        <div class="feature-item">
            <div class="feature-icon">${feature.icon}</div>
            <h3>${feature.title}</h3>
            <p>${feature.description}</p>
        </div>
    `).join('');
    
    // Add CSS for feature items
    const style = document.createElement('style');
    style.textContent = `
        .feature-item {
            background: white;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            border-top: 5px solid #D2691E;
        }
        .feature-item:hover {
            transform: translateY(-5px);
        }
        .feature-icon {
            font-size: 3em;
            margin-bottom: 15px;
        }
        #featuresSection {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin: 40px 0;
        }
    `;
    document.head.appendChild(style);
}

function initializeCounters() {
    const counters = document.querySelectorAll('.counter');
    
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = 2000; // 2 seconds
        const increment = target / (duration / 16); // 60fps
        let current = 0;
        
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                current = target;
                clearInterval(timer);
            }
            counter.textContent = Math.floor(current);
        }, 16);
    });
}

// ===== VIDEO ENHANCEMENTS =====

function initializeVideoEnhancements() {
    const videos = document.querySelectorAll('video');
    
    videos.forEach(video => {
        // Add custom controls enhancement
        video.addEventListener('play', function() {
            console.log('Video started playing:', this.src);
        });
        
        video.addEventListener('pause', function() {
            console.log('Video paused:', this.src);
        });
        
        video.addEventListener('ended', function() {
            console.log('Video completed:', this.src);
        });
    });
}

// ===== PERFORMANCE OPTIMIZATIONS =====

// Debounce function for resize events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Handle window resize efficiently
window.addEventListener('resize', debounce(function() {
    console.log('Window resized to:', window.innerWidth, 'x', window.innerHeight);
}, 250));

// ===== ERROR HANDLING =====

window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
});

// Export functions for global access (if needed)
window.VuyamahleCreations = {
    openImageModal,
    validateForm,
    initializeWebsite
};

document.addEventListener('DOMContentLoaded', function() {
    const enquiryForm = document.getElementById('enquiryForm');
    const submitBtn = document.querySelector('.submit-btn');
    const successModal = document.getElementById('successModal');
    const closeModalBtn = document.getElementById('closeSuccessModal');
    const closeModalX = document.querySelector('.close-modal');

    // Form validation
    enquiryForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        if (validateForm()) {
            submitForm();
        }
    });

    // Real-time validation
    const inputs = enquiryForm.querySelectorAll('input[required], textarea[required]');
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
        
        input.addEventListener('input', function() {
            clearError(this);
        });
    });

    // Modal functionality
    closeModalBtn.addEventListener('click', closeModal);
    closeModalX.addEventListener('click', closeModal);
    
    window.addEventListener('click', function(e) {
        if (e.target === successModal) {
            closeModal();
        }
    });

    function validateForm() {
        let isValid = true;
        const requiredFields = enquiryForm.querySelectorAll('[required]');
        
        requiredFields.forEach(field => {
            if (!validateField(field)) {
                isValid = false;
            }
        });
        
        return isValid;
    }

    function validateField(field) {
        const value = field.value.trim();
        const errorElement = document.getElementById(field.id + 'Error');
        
        if (!value) {
            showError(field, 'This field is required');
            return false;
        }
        
        if (field.type === 'email') {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                showError(field, 'Please enter a valid email address');
                return false;
            }
        }
        
        if (field.id === 'message' && value.length < 10) {
            showError(field, 'Message must be at least 10 characters long');
            return false;
        }
        
        clearError(field);
        return true;
    }

    function showError(field, message) {
        const errorElement = document.getElementById(field.id + 'Error');
        field.style.borderColor = '#e91e63';
        errorElement.textContent = message;
    }

    function clearError(field) {
        const errorElement = document.getElementById(field.id + 'Error');
        field.style.borderColor = '#e0e0e0';
        errorElement.textContent = '';
    }

    function submitForm() {
        // Show loading state
        submitBtn.classList.add('loading');
        submitBtn.disabled = true;

        // Simulate form submission
        setTimeout(() => {
            // In a real application, you would send the data to a server here
            const formData = new FormData(enquiryForm);
            const data = Object.fromEntries(formData);
            
            console.log('Form submitted:', data);
            
            // Hide loading state
            submitBtn.classList.remove('loading');
            submitBtn.disabled = false;
            
            // Show success modal
            showSuccessModal();
            
            // Reset form
            enquiryForm.reset();
        }, 2000);
    }

    function showSuccessModal() {
        successModal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }

    function closeModal() {
        successModal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }

    // Add some interactive animations
    const contactItems = document.querySelectorAll('.contact-item');
    contactItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateX(10px)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateX(0)';
        });
    });

    // Add floating animation to social links
    const socialLinks = document.querySelectorAll('.social-link');
    socialLinks.forEach(link => {
        link.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px) scale(1.1)';
        });
        
        link.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
});