#part1
 
 In part 1 I had 5 webpages which is homepage,galleryforfashion,galleryforcatring,about and contact page as i still have them now. The webpages are a basic html but somehow they will be updated once the css style is applied in part 2.


 #part2

 In part 2 I still have 5 webpages but I created an external style.css file and linked it to each and every webpages.

       Changes commited:
       In the homepage I had a video which was 1:19 minute long the I formated the size t0 00:08 seconds and also replaced the audio.
       In the aboutpage I added a picture of the founder of Vuyamahle creations at the bottom of the page.
       And In the contact page I added the send us a message section for feedbacks or trying to reach out the company for more infomation.

#part3

In part 3 I also have 5 webpages and then i created an external script.js file and Linked it to each and every webpages.

      The updates:
      The buttons I have are functioning well.
      There is a form for the target audience on the contact page where they can fill up thier details and send a message to the vuyamahle business as a feedback.
      For images in the gallery for catering and the gallery for fashion I created a lightbox with javascript and you can just click on the picture and scroll with an arrow on the right for the next picture and left for a previous picture.
      The search bar I created is a bit underwhelming in terms of activity
      The Discover more button i have at the bottom of the homepage has css styling but it seems as if the styles are not running even though i checked and got 0 errors which is disappointing but you can still click on the button as it's has the basic html feature.

For references i used the guidelines posted on arc for css style and also the textbook slides for javascript. Thank You.
